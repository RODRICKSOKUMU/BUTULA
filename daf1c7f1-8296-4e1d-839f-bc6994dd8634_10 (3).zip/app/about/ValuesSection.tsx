
'use client';

export default function ValuesSection() {
  const values = [
    {
      icon: 'ri-heart-pulse-line',
      title: 'Patient-Centered Care',
      description: 'Every decision we make is guided by what is best for our patients\' health and wellbeing.',
      color: 'text-red-500'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Quality Assurance',
      description: 'We source only the highest quality medications from verified suppliers and maintain strict storage standards.',
      color: 'text-emerald-600'
    },
    {
      icon: 'ri-user-heart-line',
      title: 'Professional Expertise',
      description: 'Our licensed pharmacists provide expert guidance and personalized health consultations.',
      color: 'text-blue-600'
    },
    {
      icon: 'ri-community-line',
      title: 'Community Trust',
      description: 'We build lasting relationships with our community through transparency and reliable service.',
      color: 'text-purple-600'
    },
    {
      icon: 'ri-smartphone-line',
      title: 'Innovation',
      description: 'We embrace technology to make healthcare more accessible and convenient for everyone.',
      color: 'text-orange-600'
    },
    {
      icon: 'ri-price-tag-3-line',
      title: 'Affordability',
      description: 'Quality healthcare should be accessible to all, which is why we offer competitive pricing.',
      color: 'text-green-600'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do at MoLife Pharmacy
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className={`w-16 h-16 ${value.color.replace('text-', 'bg-').replace('-600', '-100').replace('-500', '-100')} rounded-2xl flex items-center justify-center mb-6`}>
                  <i className={`${value.icon} text-2xl ${value.color}`}></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
