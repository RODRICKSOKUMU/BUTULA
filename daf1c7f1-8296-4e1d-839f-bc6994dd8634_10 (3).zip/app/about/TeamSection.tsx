
'use client';

export default function TeamSection() {
  const team = [
    {
      name: 'Dr. Sarah Wanjiku',
      role: 'Chief Pharmacist',
      experience: '15+ years experience',
      specialization: 'Clinical Pharmacy & Patient Care',
      image: 'Professional African female pharmacist in white coat with stethoscope, warm smile, modern pharmacy background with medicine shelves, confident healthcare professional, bright lighting, medical expertise and compassion, professional headshot style, blue and green medical environment'
    },
    {
      name: 'James Mwangi',
      role: 'Senior Pharmacist',
      experience: '12+ years experience',
      specialization: 'Medication Therapy Management',
      image: 'Professional African male pharmacist in white coat, confident expression, modern pharmacy setting with organized medicine shelves, healthcare professional consulting with patient, warm lighting, medical expertise, professional portrait style, clean pharmacy environment'
    },
    {
      name: 'Grace Akinyi',
      role: 'Community Outreach Coordinator',
      experience: '8+ years experience',
      specialization: 'Health Education & Community Programs',
      image: 'Professional African female healthcare coordinator in business attire, warm welcoming smile, modern office setting with medical certificates on wall, community health professional, bright professional lighting, healthcare leadership, blue and white office environment'
    },
    {
      name: 'David Kiprotich',
      role: 'Pharmaceutical Technician',
      experience: '10+ years experience',
      specialization: 'Quality Control & Inventory Management',
      image: 'Professional African male pharmaceutical technician in white coat, focused on quality control work, modern laboratory setting with medical equipment, precision and attention to detail, professional healthcare environment, clean organized workspace'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Meet Our Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experienced healthcare professionals dedicated to your wellbeing
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-2">
                <div className="relative mb-6">
                  <img 
                    src={`https://readdy.ai/api/search-image?query=$%7Bmember.image%7D&width=300&height=300&seq=team-${index}&orientation=squarish`}
                    alt={member.name}
                    className="w-full h-64 object-cover object-top rounded-xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl"></div>
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{member.name}</h3>
                  <p className="text-blue-600 font-semibold mb-2">{member.role}</p>
                  <p className="text-sm text-emerald-600 mb-3">{member.experience}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.specialization}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-blue-600 to-emerald-600 rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Join Our Team</h3>
              <p className="text-lg mb-6 opacity-90">
                We're always looking for passionate healthcare professionals to join our mission
              </p>
              <a 
                href="https://wa.me/254726267095?text=Hi! I'm interested in career opportunities at MoLife Pharmacy"
                className="bg-white text-blue-600 px-8 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors cursor-pointer inline-block whitespace-nowrap"
              >
                Contact HR Department
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
