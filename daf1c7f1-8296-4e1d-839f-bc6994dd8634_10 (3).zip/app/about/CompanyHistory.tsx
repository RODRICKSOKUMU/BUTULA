
'use client';

export default function CompanyHistory() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Our Story</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From humble beginnings to becoming Nairobi's trusted pharmacy partner
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="border-l-4 border-blue-600 pl-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">2020 - The Beginning</h3>
                <p className="text-gray-600 leading-relaxed">
                  MoLife Pharmacy was founded with a simple mission: to make quality healthcare 
                  accessible to everyone in Nairobi. We started as a small community pharmacy 
                  with big dreams and unwavering commitment to patient care.
                </p>
              </div>

              <div className="border-l-4 border-emerald-600 pl-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">2022 - Digital Transformation</h3>
                <p className="text-gray-600 leading-relaxed">
                  Recognizing the changing needs of our customers, we launched our digital 
                  platform, enabling convenient online ordering and WhatsApp-based consultations. 
                  This innovation brought pharmacy services directly to our customers' homes.
                </p>
              </div>

              <div className="border-l-4 border-blue-600 pl-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">2024 - Expansion & Excellence</h3>
                <p className="text-gray-600 leading-relaxed">
                  Today, MoLife Pharmacy serves thousands of customers across Nairobi, 
                  maintaining the highest standards of pharmaceutical care while embracing 
                  technology to enhance customer experience and health outcomes.
                </p>
              </div>
            </div>

            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Modern%20pharmacy%20team%20of%20diverse%20healthcare%20professionals%20in%20white%20coats%20standing%20together%20in%20bright%20contemporary%20pharmacy%20setting%2C%20shelves%20of%20medicines%20in%20background%2C%20warm%20lighting%2C%20professional%20medical%20environment%20with%20digital%20displays%20and%20modern%20equipment%2C%20team%20showing%20unity%20and%20expertise%2C%20clean%20organized%20space%20with%20blue%20and%20green%20medical%20accents%2C%20confident%20healthcare%20workers%20ready%20to%20serve%20patients&width=600&height=700&seq=company-history&orientation=portrait"
                alt="MoLife Pharmacy Team"
                className="rounded-2xl shadow-2xl w-full h-auto object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-emerald-600 text-white p-6 rounded-xl shadow-xl">
                <div className="text-center">
                  <div className="text-3xl font-bold">10,000+</div>
                  <div className="text-sm opacity-90">Happy Customers</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
