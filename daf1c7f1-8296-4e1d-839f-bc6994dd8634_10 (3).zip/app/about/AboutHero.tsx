
'use client';

export default function AboutHero() {
  return (
    <section className="relative min-h-[500px] flex items-center justify-center bg-gradient-to-br from-blue-50 to-emerald-50">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20modern%20pharmacy%20interior%20with%20clean%20white%20shelves%20stocked%20with%20medicine%20bottles%20and%20healthcare%20products%2C%20bright%20lighting%20creating%20a%20welcoming%20atmosphere%2C%20glass%20display%20cases%20with%20medical%20equipment%2C%20modern%20pharmaceutical%20setting%20with%20sterile%20surfaces%20and%20organized%20layout%2C%20healthcare%20professionals%20in%20white%20coats%20consulting%20with%20patients%20in%20background%2C%20creating%20sense%20of%20trust%20and%20medical%20expertise%2C%20minimalist%20design%20with%20blue%20and%20green%20accents&width=1200&height=600&seq=about-hero&orientation=landscape')`
        }}
      ></div>
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6">
            About <span className="text-blue-600">MoLife</span> <span className="text-emerald-600">Pharmacy</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
            Your Fountain of Health - Committed to providing quality healthcare solutions 
            and exceptional pharmaceutical services to the Nairobi community
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full shadow-md">
              <div className="flex items-center space-x-2">
                <i className="ri-shield-check-line text-emerald-600 text-lg"></i>
                <span className="text-gray-700 font-medium">Licensed Pharmacy</span>
              </div>
            </div>
            <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full shadow-md">
              <div className="flex items-center space-x-2">
                <i className="ri-time-line text-blue-600 text-lg"></i>
                <span className="text-gray-700 font-medium">24/7 Support</span>
              </div>
            </div>
            <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-full shadow-md">
              <div className="flex items-center space-x-2">
                <i className="ri-truck-line text-emerald-600 text-lg"></i>
                <span className="text-gray-700 font-medium">Fast Delivery</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
