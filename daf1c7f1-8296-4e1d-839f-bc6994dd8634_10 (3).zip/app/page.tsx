'use client';

import Hero from '../components/Hero';
import FeaturedProducts from '../components/FeaturedProducts';
import Services from '../components/Services';
import WhyChooseUs from '../components/WhyChooseUs';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Services />
      <FeaturedProducts />
      <WhyChooseUs />
      <Footer />
    </div>
  );
}