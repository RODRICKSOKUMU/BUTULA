
'use client';

export default function ContactInfo() {
  const contactMethods = [
    {
      icon: 'ri-whatsapp-line',
      title: 'WhatsApp Chat',
      description: 'Get instant support',
      contact: '+254 726 267 095',
      action: 'Chat Now',
      link: 'https://wa.me/254726267095',
      color: 'bg-green-100 text-green-600',
      buttonColor: 'bg-green-600 hover:bg-green-700'
    },
    {
      icon: 'ri-phone-line',
      title: 'Phone Support',
      description: 'Call us directly',
      contact: '+254 726 267 095',
      action: 'Call Now',
      link: 'tel:+254726267095',
      color: 'bg-blue-100 text-blue-600',
      buttonColor: 'bg-blue-600 hover:bg-blue-700'
    },
    {
      icon: 'ri-mail-line',
      title: 'Email Support',
      description: 'Send us an email',
      contact: 'info@molifepharmacy.co.ke',
      action: 'Email Us',
      link: 'mailto:info@molifepharmacy.co.ke',
      color: 'bg-purple-100 text-purple-600',
      buttonColor: 'bg-purple-600 hover:bg-purple-700'
    }
  ];

  const businessHours = [
    { day: 'Monday - Friday', hours: '8:00 AM - 8:00 PM' },
    { day: 'Saturday', hours: '9:00 AM - 6:00 PM' },
    { day: 'Sunday', hours: '10:00 AM - 4:00 PM' },
    { day: 'Emergency Support', hours: '24/7 Available' }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Contact Information</h2>
            <p className="text-lg text-gray-600">
              Multiple ways to reach us for all your healthcare needs
            </p>
          </div>

          <div className="space-y-6 mb-12">
            {contactMethods.map((method, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${method.color}`}>
                      <i className={`${method.icon} text-xl`}></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 text-lg">{method.title}</h3>
                      <p className="text-gray-600 text-sm mb-1">{method.description}</p>
                      <p className="font-medium text-gray-800">{method.contact}</p>
                    </div>
                  </div>
                  <a
                    href={method.link}
                    className={`${method.buttonColor} text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap`}
                  >
                    {method.action}
                  </a>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Business Hours</h3>
            <div className="space-y-4">
              {businessHours.map((schedule, index) => (
                <div key={index} className={`flex justify-between items-center py-3 px-4 rounded-xl ${
                  schedule.day === 'Emergency Support' 
                    ? 'bg-emerald-50 border border-emerald-200' 
                    : 'bg-gray-50'
                }`}>
                  <span className={`font-medium ${
                    schedule.day === 'Emergency Support' ? 'text-emerald-700' : 'text-gray-700'
                  }`}>
                    {schedule.day}
                  </span>
                  <span className={`font-semibold ${
                    schedule.day === 'Emergency Support' ? 'text-emerald-600' : 'text-gray-800'
                  }`}>
                    {schedule.hours}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-gradient-to-r from-blue-600 to-emerald-600 rounded-2xl p-8 text-white text-center">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-customer-service-2-line text-2xl"></i>
            </div>
            <h3 className="text-xl font-bold mb-3">24/7 Emergency Support</h3>
            <p className="opacity-90 mb-6">
              Need urgent medical assistance? Our emergency support team is available around the clock 
              to help with critical health situations and medication emergencies.
            </p>
            <a 
              href="https://wa.me/254726267095?text=EMERGENCY: I need immediate medical assistance"
              className="bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-gray-100 transition-colors cursor-pointer inline-block whitespace-nowrap"
            >
              Emergency Contact
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
