
'use client';

export default function LocationMap() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Visit Our Location</h2>
            <p className="text-lg text-gray-600">
              Find us in the heart of Nairobi - Your fountain of health is just around the corner
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-blue-50 to-emerald-50 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">MoLife Pharmacy</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                      <i className="ri-map-pin-line text-white text-sm"></i>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Address</p>
                      <p className="text-gray-600">Nairobi CBD, Kenya</p>
                      <p className="text-gray-600">Convenient location near major transport hubs</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                      <i className="ri-car-line text-white text-sm"></i>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Parking</p>
                      <p className="text-gray-600">Free customer parking available</p>
                      <p className="text-gray-600">Easy access and wheelchair friendly</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                      <i className="ri-bus-line text-white text-sm"></i>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Public Transport</p>
                      <p className="text-gray-600">Multiple matatu routes nearby</p>
                      <p className="text-gray-600">Walking distance from CBD bus stations</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-white rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-gray-800">Need Directions?</p>
                      <p className="text-gray-600 text-sm">Get turn-by-turn navigation</p>
                    </div>
                    <a 
                      href="https://wa.me/254726267095?text=Hi! Can you please share your exact location and directions?"
                      className="bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Get Directions
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gray-100 rounded-2xl overflow-hidden shadow-lg h-96">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.8198480814447!2d36.8194!3d-1.2864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f10d640000000%3A0x0!2sNairobi%2C%20Kenya!5e0!3m2!1sen!2sus!4v1635000000000!5m2!1sen!2sus"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="MoLife Pharmacy Location"
                ></iframe>
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
                    <i className="ri-map-pin-fill text-white text-lg"></i>
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">We're Here!</p>
                    <p className="text-gray-600 text-sm">Easy to find & access</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-time-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Extended Hours</h3>
              <p className="text-gray-600 text-sm">Open late and weekends for your convenience</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-truck-line text-emerald-600 text-2xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Home Delivery</h3>
              <p className="text-gray-600 text-sm">Can't visit? We deliver to your doorstep</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-customer-service-2-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Expert Consultation</h3>
              <p className="text-gray-600 text-sm">Licensed pharmacists ready to help</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
