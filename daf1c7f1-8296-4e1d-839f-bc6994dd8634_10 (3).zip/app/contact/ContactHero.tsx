
'use client';

export default function ContactHero() {
  return (
    <section className="relative min-h-[400px] flex items-center justify-center bg-gradient-to-br from-blue-600 to-emerald-600">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20pharmacy%20customer%20service%20counter%20with%20friendly%20staff%20helping%20customers%2C%20professional%20healthcare%20environment%2C%20clean%20white%20interior%20with%20medicine%20displays%2C%20welcoming%20atmosphere%2C%20people%20consulting%20with%20pharmacists%2C%20bright%20lighting%2C%20medical%20consultation%20area%20with%20comfortable%20seating%2C%20blue%20and%20green%20accents%2C%20professional%20healthcare%20setting&width=1200&height=500&seq=contact-hero&orientation=landscape')`
        }}
      ></div>
      
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Get In Touch
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90 leading-relaxed">
            We're here to help with all your healthcare needs. Reach out to us anytime, anywhere.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full">
              <i className="ri-phone-line text-xl"></i>
              <span className="font-medium">24/7 Support</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full">
              <i className="ri-chat-3-line text-xl"></i>
              <span className="font-medium">WhatsApp Ready</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full">
              <i className="ri-truck-line text-xl"></i>
              <span className="font-medium">Fast Response</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
