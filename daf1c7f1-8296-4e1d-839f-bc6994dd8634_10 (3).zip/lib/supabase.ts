import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  original_price?: number;
  image: string;
  in_stock: boolean;
  description?: string;
  featured?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Order {
  id: number;
  customer_name?: string;
  customer_phone?: string;
  items: any[];
  total_amount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'completed' | 'cancelled';
  whatsapp_sent: boolean;
  created_at?: string;
  updated_at?: string;
}