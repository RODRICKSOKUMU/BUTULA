'use client';

export default function WhyChooseUs() {
  const features = [
    {
      number: '10+',
      title: 'Years Experience',
      description: 'Serving the community with trusted pharmaceutical care'
    },
    {
      number: '5000+',
      title: 'Happy Customers',
      description: 'Satisfied clients who trust us for their health needs'
    },
    {
      number: '1000+',
      title: 'Products Available',
      description: 'Wide range of medicines and healthcare products'
    },
    {
      number: '24/7',
      title: 'Customer Support',
      description: 'Always available to help with your health concerns'
    }
  ];

  return (
    <section 
      className="py-20 bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `linear-gradient(rgba(16, 185, 129, 0.9), rgba(16, 185, 129, 0.8)), url('https://readdy.ai/api/search-image?query=Professional%20pharmacy%20team%20of%20pharmacists%20in%20white%20coats%20consulting%20with%20customers%2C%20modern%20pharmacy%20interior%20with%20organized%20medicine%20shelves%2C%20warm%20lighting%20creating%20trustworthy%20healthcare%20environment%2C%20people%20interacting%20professionally&width=1400&height=600&seq=why001&orientation=landscape')`
      }}
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Trusted by Thousands</h2>
          <p className="text-xl text-emerald-100 max-w-3xl mx-auto">
            Our commitment to quality healthcare has made us a preferred choice for families across Kenya
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center text-white">
              <div className="text-5xl font-bold mb-4 text-emerald-100">
                {feature.number}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-emerald-100 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}