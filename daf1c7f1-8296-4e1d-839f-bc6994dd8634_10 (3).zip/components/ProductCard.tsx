
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Product } from '../lib/supabase';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [imageLoading, setImageLoading] = useState(true);

  const handleAddToCart = () => {
    const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItem = cartItems.find((item: any) => item.id === product.id);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cartItems.push({ ...product, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cartItems));
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow group">
      <Link href={`/products/${product.id}`}>
        <div className="relative overflow-hidden cursor-pointer">
          <img
            src={product.image}
            alt={product.name}
            className={`w-full h-64 object-cover object-top transition-transform group-hover:scale-105 ${
              imageLoading ? 'bg-gray-200 animate-pulse' : ''
            }`}
            onLoad={() => setImageLoading(false)}
          />
          {product.featured && (
            <div className="absolute top-3 left-3 bg-emerald-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
              Featured
            </div>
          )}
          {!product.in_stock && (
            <div className="absolute inset-0 bg-gray-900/50 flex items-center justify-center">
              <span className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold">
                Out of Stock
              </span>
            </div>
          )}
        </div>
      </Link>

      <div className="p-6">
        <div className="mb-2">
          <span className="text-sm text-emerald-600 font-medium">{product.category}</span>
        </div>
        
        <Link href={`/products/${product.id}`}>
          <h3 className="text-lg font-semibold text-gray-800 mb-3 hover:text-emerald-600 cursor-pointer">
            {product.name}
          </h3>
        </Link>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-gray-800">
              KSH {product.price.toLocaleString()}
            </span>
            {product.original_price && (
              <span className="text-sm text-gray-500 line-through">
                KSH {product.original_price.toLocaleString()}
              </span>
            )}
          </div>
        </div>

        <button
          onClick={handleAddToCart}
          disabled={!product.in_stock}
          className={`w-full py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer ${
            product.in_stock
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          {product.in_stock ? 'Add to Cart' : 'Out of Stock'}
        </button>
      </div>
    </div>
  );
}
