
'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section 
      className="relative min-h-screen bg-cover bg-center bg-no-repeat flex items-center"
      style={{
        backgroundImage: `linear-gradient(rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.2)), url('https://readdy.ai/api/search-image?query=Modern%20pharmacy%20interior%20with%20clean%20white%20shelves%20filled%20with%20organized%20medicine%20bottles%20and%20healthcare%20products%2C%20professional%20lighting%20creating%20a%20calm%20and%20trustworthy%20atmosphere%2C%20soft%20green%20and%20white%20color%20scheme%2C%20minimalist%20design%20with%20medical%20equipment%20visible%2C%20creating%20sense%20of%20health%20and%20wellness%2C%20clean%20modern%20aesthetic&width=1400&height=800&seq=hero001&orientation=landscape')`
      }}
    >
      <div className="container mx-auto px-4 w-full">
        <div className="max-w-2xl">
          <h1 className="text-5xl md:text-6xl font-bold text-blue-800 mb-6 leading-tight">
            Your Fountain
            <span className="text-emerald-600 block">of Health</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Quality medicines, expert care, and convenient delivery. 
            MoLife Pharmacy brings healthcare to your doorstep with professional consultation and genuine products.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/products">
              <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                Shop Now
              </button>
            </Link>
            <Link href="/contact">
              <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                Consult Pharmacist
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
