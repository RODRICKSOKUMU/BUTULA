
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartItems] = useState(0);

  return (
    <header className="bg-white shadow-md relative z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-12 h-12 flex items-center justify-center">
              <img 
                src="https://static.readdy.ai/image/6a0f0a0b7fdbf84a6287fe1c9f0cedf7/7dffe2e383af1e7292d3d9864cdf5586.jfif" 
                alt="MoLife Pharmacy Logo" 
                className="w-12 h-12 object-contain"
              />
            </div>
            <span className="font-[\'Pacifico\'] text-2xl text-blue-600">MoLife Pharmacy</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              Home
            </Link>
            <Link href="/products" className="text-gray-700 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              Products
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              About Us
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              Contact
            </Link>
            <Link href="/admin" className="text-gray-700 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              Admin
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="/cart" className="relative cursor-pointer">
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-shopping-cart-line text-xl text-gray-700 hover:text-emerald-600"></i>
              </div>
              {cartItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-emerald-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItems}
                </span>
              )}
            </Link>
            
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer"
            >
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl text-gray-700`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-3 pt-4">
              <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/products" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Products
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                About Us
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Contact
              </Link>
              <Link href="/admin" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Admin
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
