
'use client';

import Link from 'next/link';

interface AdminHeaderProps {
  onLogout?: () => void;
}

export default function AdminHeader({ onLogout }: AdminHeaderProps) {
  return (
    <header className="bg-white shadow-md border-b-2 border-blue-600">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-12 h-12 flex items-center justify-center">
                <img 
                  src="https://static.readdy.ai/image/6a0f0a0b7fdbf84a6287fe1c9f0cedf7/7dffe2e383af1e7292d3d9864cdf5586.jfif" 
                  alt="MoLife Pharmacy Logo" 
                  className="w-12 h-12 object-contain"
                />
              </div>
              <span className="font-[\'Pacifico\'] text-2xl text-blue-600">MoLife Pharmacy</span>
            </Link>
            <div className="hidden md:block w-px h-6 bg-gray-300"></div>
            <span className="hidden md:block text-lg font-semibold text-gray-700">Admin Panel</span>
          </div>

          <nav className="flex items-center space-x-6">
            <Link href="/admin" className="text-gray-700 hover:text-blue-600 transition-colors font-medium whitespace-nowrap cursor-pointer">
              Dashboard
            </Link>
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors font-medium whitespace-nowrap cursor-pointer">
              View Website
            </Link>
            {onLogout && (
              <button
                onClick={onLogout}
                className="bg-red-100 hover:bg-red-200 text-red-600 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
              >
                Logout
              </button>
            )}
            <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-gray-200 transition-colors">
              <i className="ri-user-line text-gray-600 text-lg"></i>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
