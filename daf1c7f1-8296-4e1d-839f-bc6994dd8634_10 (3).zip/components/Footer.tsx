
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-blue-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-12 h-12 flex items-center justify-center">
                <img 
                  src="https://static.readdy.ai/image/6a0f0a0b7fdbf84a6287fe1c9f0cedf7/7dffe2e383af1e7292d3d9864cdf5586.jfif" 
                  alt="MoLife Pharmacy Logo" 
                  className="w-12 h-12 object-contain"
                />
              </div>
              <span className="font-['Pacifico'] text-2xl text-emerald-400">MoLife Pharmacy</span>
            </div>
            <p className="text-gray-300 leading-relaxed mb-6">
              Your fountain of health. Quality medicines, expert care, and convenient delivery.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-blue-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-lg"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-blue-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-lg"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-blue-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                <i className="ri-instagram-fill text-lg"></i>
              </a>
              <a href="https://wa.me/254726267095" className="w-10 h-10 bg-blue-800 rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors cursor-pointer">
                <i className="ri-whatsapp-fill text-lg"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li><Link href="/products" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Products</Link></li>
              <li><Link href="/about" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">About Us</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Contact</Link></li>
              <li><Link href="/cart" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Cart</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6">Categories</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Pain Relief</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Antibiotics</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Supplements</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors cursor-pointer">Medical Devices</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6">Contact Info</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <i className="ri-map-pin-line text-emerald-400 text-lg mt-1"></i>
                <div>
                  <p className="text-gray-300">Nairobi, Kenya</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-phone-line text-emerald-400 text-lg"></i>
                <p className="text-gray-300">+254 726 267 095</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-mail-line text-emerald-400 text-lg"></i>
                <p className="text-gray-300">info@molifepharmacy.co.ke</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-time-line text-emerald-400 text-lg"></i>
                <p className="text-gray-300">Mon-Sun: 24/7 Support</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-blue-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-center md:text-left mb-4 md:mb-0">
              <p className="text-gray-400 text-sm">
                2024 MoLife Pharmacy. All rights reserved.
              </p>
              <p className="text-gray-400 text-xs mt-1">
                Designed by Rodricks Okumu Nakhumwa
              </p>
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">Terms of Service</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
