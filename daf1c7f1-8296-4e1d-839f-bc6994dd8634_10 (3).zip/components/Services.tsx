'use client';

export default function Services() {
  const services = [
    {
      icon: 'ri-truck-line',
      title: 'Free Delivery',
      description: 'Fast and reliable delivery to your doorstep for orders above KSH 2,000'
    },
    {
      icon: 'ri-customer-service-2-line',
      title: '24/7 Support',
      description: 'Round-the-clock customer support and pharmaceutical consultation'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Genuine Products',
      description: 'All medicines are sourced from certified manufacturers and distributors'
    },
    {
      icon: 'ri-whatsapp-line',
      title: 'WhatsApp Orders',
      description: 'Easy ordering and verification process through WhatsApp integration'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Why Choose MoLife Pharmacy?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We are committed to providing quality healthcare solutions with convenience and trust
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className={`${service.icon} text-2xl text-emerald-600`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}